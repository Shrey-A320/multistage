﻿namespace MWP.Notification.TestUtilities.Builders
{
    public class NotificationParametersBuilder
    {

    }
}
