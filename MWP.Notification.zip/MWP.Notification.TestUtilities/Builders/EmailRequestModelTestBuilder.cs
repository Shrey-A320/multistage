﻿using MWP.Notification.Domain.EmailModels;
using MWP.Notification.Domain.Enums;

namespace MWP.Notification.TestUtilities.Builders
{
    public class EmailRequestModelTestBuilder
    {
        private Guid _correlationId;
        private string _context = string.Empty;
        private string _createdBy = string.Empty;
        private DateTime _createdOn;
        private NotificationSource _source;
        private NotificationType _notificationType;
        private NotificationSeverity _severity;
        private bool _audit;
        private List<string> _attachments = new List<string>();
        private EmailProvider _emailProvider;
        private string _containerName = string.Empty;
        private EmailHeader _emailHeader = new EmailHeader();
        private List<string> _notifyFailureEmail = new List<string>();



        private string _cosmosDbDatabaseID = string.Empty;
        private string _cosmosDbConnectionString = string.Empty;
        public EmailRequestModelTestBuilder WithCorrelationId(Guid correlationId)
        {
            _correlationId = correlationId;
            return this;
        }
        public EmailRequestModelTestBuilder WithContext(string context)
        {
            _context = context;
            return this;
        }
        public EmailRequestModelTestBuilder WithCreatedBy(string createdBy)
        {
            _createdBy = createdBy;
            return this;
        }
        public EmailRequestModelTestBuilder WithCreatedOn(DateTime createdOn)
        {
            _createdOn = createdOn;
            return this;
        }
        public EmailRequestModelTestBuilder WithSource(NotificationSource source)
        {
            _source = source;
            return this;
        }
        public EmailRequestModelTestBuilder WithNotificationType(NotificationType notificationType)
        {
            _notificationType = notificationType;
            return this;
        }
        public EmailRequestModelTestBuilder WithNotificationSeverity(NotificationSeverity severity)
        {
            _severity = severity;
            return this;
        }
        public EmailRequestModelTestBuilder WithAudit(bool audit)
        {
            _audit = audit;
            return this;
        }
        public EmailRequestModelTestBuilder WithAttachments(List<string> attachments)
        {
            _attachments = attachments;
            return this;
        }
        public EmailRequestModelTestBuilder WithEmailProvider(EmailProvider emailProvider)
        {
            _emailProvider = emailProvider;
            return this;
        }
        public EmailRequestModelTestBuilder WithContainerName(string containerName)
        {
            _containerName = containerName;
            return this;
        }
        public EmailRequestModelTestBuilder WithEmailHeader(EmailHeader emailHeader)
        {
            _emailHeader = emailHeader;
            return this;
        }
        public EmailRequestModelTestBuilder WithNotifyFailureEmail(List<string> notifyFailureEmail)
        {
            _notifyFailureEmail = notifyFailureEmail;
            return this;
        }
        public EmailRequestModel Build() =>
            new()
            {
                CorrelationId = _correlationId,
                Attachments = _attachments,
                EmailProvider = _emailProvider,
                ContainerName = _containerName,
                EmailHeader = _emailHeader,
                NotifyFailureEmail = _notifyFailureEmail,
                Audit = _audit,
                Context = _context,
                CreatedBy = _createdBy,
                CreatedOn = _createdOn,
                NotificationType = _notificationType,
                Severity = _severity,
                Source = _source,
            };
    }
}
