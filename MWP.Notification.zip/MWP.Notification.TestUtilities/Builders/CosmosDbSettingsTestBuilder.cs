﻿using MWP.Notification.Infrastructure.Models;
namespace MWP.TradeService.TestUtilities.Builders.Dtos
{
    public class CosmosDbSettingsTestBuilder
    {
        private string _cosmosDbDatabaseID = string.Empty;
        private string _cosmosDbConnectionString = string.Empty;
        private string _cosmosDbContainerID = string.Empty;
        private string _cosmosDbPartitionKey = string.Empty;
        public CosmosDbSettingsTestBuilder WithCosmosDbDatabaseID(string cosmosDbDatabaseID)
        {
            _cosmosDbDatabaseID = cosmosDbDatabaseID;
            return this;
        }
        public CosmosDbSettingsTestBuilder WithCosmosDbConnectionString(string cosmosDbConnectionString)
        {
            _cosmosDbConnectionString = cosmosDbConnectionString;
            return this;
        }
        public CosmosDbSettings Build() =>
            new(_cosmosDbDatabaseID, _cosmosDbConnectionString, _cosmosDbContainerID)
            {
            };
    }
}
