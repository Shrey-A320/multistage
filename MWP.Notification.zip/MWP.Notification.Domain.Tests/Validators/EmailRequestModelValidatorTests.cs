﻿using MWP.Notification.Common.Constants;

namespace MWP.Notification.Domain.Tests.Validators
{
    public class EmailRequestModelValidatorTests
    {

        private readonly EmailRequestModelValidator _validator;

        public EmailRequestModelValidatorTests()
        {
            _validator = new EmailRequestModelValidator();
        }

        [Fact]
        public void Should_Have_Error_When_CorrelationId_Is_Empty()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithContext("Test")
            .Build();

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.CorrelationId)
                  .WithErrorMessage(ValidationMessages.CorrelationIdEmpty);
        }

        [Fact]
        public void Should_Have_Error_When_Context_Is_Empty()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Context)
                  .WithErrorMessage(ValidationMessages.ContextEmpty);
        }

        [Fact]
        public void Should_Have_Error_When_CreatedBy_Is_Empty()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithContext("Test")
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.CreatedBy)
                  .WithErrorMessage(ValidationMessages.CreatedByEmpty);
        }

        [Fact]
        public void Should_Have_Error_When_CreatedOn_Is_Empty()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithContext("Test")
            .WithCreatedBy("11021")
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.CreatedOn)
                  .WithErrorMessage(ValidationMessages.CreatedOnEmpty);
        }

        [Fact]
        public void Validation_Should_Fail_For_Invalid_Source()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithNotificationType(NotificationType.Email)
            .WithSource((NotificationSource)999)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithContext("Test")
            .WithCreatedBy("11021")
            .WithCreatedOn(DateTime.Now)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();
            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Source)
                  .WithErrorMessage(ValidationMessages.SourceInvalid);
        }

        [Fact]
        public void Validation_Should_Fail_For_Invalid_NotificationType()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithNotificationType((NotificationType)999)
            .WithSource(NotificationSource.Process)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithContext("Test")
            .WithCreatedBy("11021")
            .WithCreatedOn(DateTime.Now)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();
            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.NotificationType)
                  .WithErrorMessage(ValidationMessages.NotificationTypeInvalid);
        }

        [Fact]
        public void Validation_Should_Fail_For_Invalid_Severity()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithNotificationType(NotificationType.Email)
            .WithSource(NotificationSource.Process)
            .WithNotificationSeverity((NotificationSeverity)999)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithContext("Test")
            .WithCreatedBy("11021")
            .WithCreatedOn(DateTime.Now)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();
            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Severity)
                  .WithErrorMessage(ValidationMessages.SeverityInvalid);
        }

        [Fact]
        public void Validation_Should_Fail_For_Invalid_EmailProvider()
        {
            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithNotificationType(NotificationType.Email)
            .WithSource(NotificationSource.Process)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider((EmailProvider)999)
            .WithContext("Test")
            .WithCreatedBy("11021")
            .WithCreatedOn(DateTime.Now)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();
            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.EmailProvider)
                  .WithErrorMessage(ValidationMessages.EmailProviderInvalid);
        }
    }
}
