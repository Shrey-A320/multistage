﻿using MWP.Notification.Common.Constants;

namespace MWP.Notification.Domain.Tests.Validators
{
    public class EmailHeaderValidatorTests
    {
        private readonly EmailHeaderValidator _validator;

        public EmailHeaderValidatorTests()
        {
            _validator = new EmailHeaderValidator();
        }

        [Fact]
        public void Should_Have_Error_When_Sender_Is_Empty()
        {
            var emailRequestModel = new EmailHeader()
            {
                SenderName = "Test",
                To = new List<string> { "Test@gmail.com" },
                Subject = "TestEmail",
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Sender)
                  .WithErrorMessage(ValidationMessages.SenderEmpty);
        }

        [Fact]
        public void Should_Have_Error_When_SenderName_Is_Empty()
        {
            var emailRequestModel = new EmailHeader()
            {
                Sender = "TestUser@gmail.com",
                To = new List<string> { "Test@gmail.com" },
                Subject = "TestEmail",
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.SenderName)
                  .WithErrorMessage(ValidationMessages.SenderNameEmpty);
        }
        [Fact]
        public void Should_Have_Error_When_To_Is_Empty()
        {
            var emailRequestModel = new EmailHeader()
            {
                Sender = "TestUser@gmail.com",
                SenderName = "Test",
                Subject = "TestEmail",
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.To)
                  .WithErrorMessage(ValidationMessages.ToEmpty);
        }
        [Fact]
        public void Should_Have_Error_When_To_Has_InvalidEmail()
        {
            var emailRequestModel = new EmailHeader()
            {
                Sender = "TestUser@gmail.com",
                SenderName = "Test",
                To = new List<string> { "TestWrongEmail" },
                Subject = "TestEmail",
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.To)
                  .WithErrorMessage(ValidationMessages.ToInvalid);
        }
        [Fact]
        public void Should_Have_Error_When_Cc_Has_InvalidEmail()
        {
            var emailRequestModel = new EmailHeader()
            {
                Sender = "TestUser@gmail.com",
                SenderName = "Test",
                To = new List<string> { "Test@gmail.com" },
                Cc = new List<string> { "TestWrongEmail"},
                Subject = "TestEmail",
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Cc)
                  .WithErrorMessage(ValidationMessages.CcInvalid);
        }
        [Fact]
        public void Should_Have_Error_When_Bcc_Has_InvalidEmail()
        {
            var emailRequestModel = new EmailHeader()
            {
                Sender = "TestUser@gmail.com",
                SenderName = "Test",
                To = new List<string> { "Test@gmail.com" },
                Cc = new List<string> { "TestEmail@gmail.com" },
                Bcc = new List<string> { "TestWrongEmail" },
                Subject = "TestEmail",
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Bcc)
                  .WithErrorMessage(ValidationMessages.BccInvalid);
        }
        [Fact]
        public void Should_Have_Error_When_Subject_Is_Empty()
        {
            var emailRequestModel = new EmailHeader()
            {
                Sender = "TestUser@gmail.com",
                SenderName = "Test",
                To = new List<string> { "Test@gmail.com" },
            };

            var result = _validator.TestValidate(emailRequestModel);
            result.ShouldHaveValidationErrorFor(x => x.Subject)
                  .WithErrorMessage(ValidationMessages.SubjectEmpty);
        }
    }
}
