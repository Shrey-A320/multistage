global using Xunit;
global using Microsoft.Extensions.Logging;
global using Moq;
global using MWP.Notification.Domain;
global using MWP.Notification.Domain.Enums;
global using MWP.Notification.Service.Abstract;
global using MWP.Notification.Service.Interfaces;
global using Microsoft.Extensions.Options;
global using MWP.Notification.Common.Configurations;
global using MWP.Notification.Domain.EmailModels;
global using MWP.Notification.Infrastructure.Interfaces;
global using MWP.Notification.Service.Factories;
global using Microsoft.Extensions.DependencyInjection;
global using MWP.Notification.Service.ServiceProvider;
global using System.Text;
global using AutoMapper;
global using MWP.Notification.TestUtilities.Builders;

