﻿namespace MWP.Notification.Service.Tests.Abstract
{
    public class NotificationServiceTests
    {
        private readonly Mock<ILogger> _mockLogger;
        private readonly Mock<MockNotificationRequestModel> _mockNotificationRequestModel;
        private readonly Mock<NotificationResponseModel> _mockNotificationResponseModel;

        public NotificationServiceTests()
        {
            _mockLogger = new Mock<ILogger>();
            _mockNotificationRequestModel = new Mock<MockNotificationRequestModel>();
            _mockNotificationResponseModel = new Mock<NotificationResponseModel>();
        }

        [Fact]
        public async Task BuildAndSendNotificationAsync_ValidRequest_ReturnsResponse()
        {
            // Arrange
            var service = new MockNotificationService(_mockLogger.Object);
            var notificationRequestModel = _mockNotificationRequestModel.Object;

            // Act
            var result = await service.BuildAndSendNotificationAsync(notificationRequestModel);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<NotificationResponseModel>(result);
        }

        [Fact]
        public async Task BuildAndSendNotificationAsync_InvalidRequest_ThrowsException()
        {
            // Arrange
            var service = new MockNotificationService(_mockLogger.Object);
            var invalidNotificationRequestModel = (MockNotificationRequestModel)null; // Simulating an invalid request

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => service.BuildAndSendNotificationAsync(invalidNotificationRequestModel));
        }

        [Fact]
        public void ConvertToObject_ValidBinaryData_ReturnsNotificationRequestModel()
        {
            // Arrange
            var service = new MockNotificationService(_mockLogger.Object);
            var binaryData = BinaryData.FromObjectAsJson(_mockNotificationRequestModel.Object);

            // Act
            var result = service.ConvertToObject(binaryData);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<MockNotificationRequestModel>(result);
        }

        [Fact]
        public void ConvertToObject_InvalidBinaryData_ThrowsException()
        {
            // Arrange
            var service = new MockNotificationService(_mockLogger.Object);
            var invalidBinaryData = BinaryData.FromString("invalid data"); // Simulating invalid binary data

            // Act & Assert
            Assert.Throws<FormatException>(() => service.ConvertToObject(invalidBinaryData));
        }

        [Fact]
        public async Task INotificationFactory_BuildAndSendNotificationAsync_ValidRequest_ReturnsResponse()
        {
            // Arrange
            var service = new MockNotificationService(_mockLogger.Object);
            var notificationRequestModel = _mockNotificationRequestModel.Object;

            // Act
            var result = await ((INotificationFactory)service).BuildAndSendNotificationAsync(notificationRequestModel);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<NotificationResponseModel>(result);
        }

        [Fact]
        public async Task INotificationFactory_BuildAndSendNotificationAsync_InvalidRequest_ThrowsException()
        {
            // Arrange
            var service = new MockNotificationService(_mockLogger.Object);
            var invalidNotificationRequestModel = (INotificationRequestModel)null; // Simulating an invalid request

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => ((INotificationFactory)service).BuildAndSendNotificationAsync(invalidNotificationRequestModel));
        }

        // Mock implementation of NotificationService for testing
        public class MockNotificationService : NotificationService<MockNotificationRequestModel>
        {
            public MockNotificationService(ILogger logger) : base(logger) { }

            public override Task<NotificationResponseModel> BuildAndSendNotificationAsync(MockNotificationRequestModel notificationRequestModel)
            {
                if (notificationRequestModel == null)
                {
                    throw new ArgumentNullException(nameof(notificationRequestModel), "Notification request model cannot be null.");
                }

                return Task.FromResult(new NotificationResponseModel(200, true, null));
            }
        }

        // Mock implementation of INotificationRequestModel for testing
        public class MockNotificationRequestModel : INotificationRequestModel
        {
            public Guid CorrelationId { get; set; }
            public string Context { get; set; }
            public string CreatedBy { get; set; }
            public DateTime CreatedOn { get; set; }
            public NotificationSource Source { get; set; }
            public NotificationType NotificationType { get; set; }
            public NotificationSeverity Severity { get; set; }
            public bool Audit { get; set; }
            public List<string> Attachments { get; set; }
        }
    }
}
