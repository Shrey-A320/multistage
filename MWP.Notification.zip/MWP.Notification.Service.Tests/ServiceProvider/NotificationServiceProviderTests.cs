﻿namespace MWP.Notification.Service.Tests.ServiceProvider
{
    public class NotificationServiceProviderTests
    {
        private readonly Mock<IKeyedServiceProvider> _mockKeyedServiceProvider;
        private readonly Mock<INotificationFactory> _mockNotificationFactory;
        private readonly Mock<ILogger<NotificationServiceProvider>> _mockLogger;
        private readonly NotificationServiceProvider _notificationServiceProvider;

        public NotificationServiceProviderTests()
        {
            _mockKeyedServiceProvider = new Mock<IKeyedServiceProvider>();
            _mockNotificationFactory = new Mock<INotificationFactory>();
            _mockLogger = new Mock<ILogger<NotificationServiceProvider>>();
            _notificationServiceProvider = new NotificationServiceProvider(_mockLogger.Object, _mockKeyedServiceProvider.Object);
        }

        [Fact]
        public async Task Provider_WhenEmailNotificationType_ShouldReturnNotificationResponseModel()
        {
            // Arrange
            string jsonEventData = "{\"NotificationType\":\"Email\",\"OtherField\":\"value\"}";
            byte[] eventData = Encoding.UTF8.GetBytes(jsonEventData);
            var cloudEventData = new BinaryData(eventData);

            var expectedResponse = new NotificationResponseModel(202, true, string.Empty);

            _mockNotificationFactory.Setup(factory => factory.ConvertToObject(It.IsAny<BinaryData>()))
                .Returns(It.IsAny<INotificationRequestModel>());

            _mockKeyedServiceProvider.Setup(x => x.GetRequiredKeyedService(typeof(INotificationFactory), NotificationType.Email)).Returns(_mockNotificationFactory.Object);

            _mockNotificationFactory.Setup(factory => factory.BuildAndSendNotificationAsync(It.IsAny<INotificationRequestModel>()))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _notificationServiceProvider.GetServiceAsync(cloudEventData);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccessStatusCode);
        }

        [Fact]
        public async Task Provider_WhenInvalidNotificationType_ShouldThrowException()
        {
            // Arrange
            string jsonEventData = "{\"NotificationType\":\"InvalidType\",\"OtherField\":\"value\"}";
            byte[] eventData = Encoding.UTF8.GetBytes(jsonEventData);
            var cloudEventData = new BinaryData(eventData);

            _mockKeyedServiceProvider.Setup(x => x.GetRequiredKeyedService(typeof(INotificationFactory), It.IsAny<string>())).Throws(new InvalidOperationException("Service not found"));

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => _notificationServiceProvider.GetServiceAsync(cloudEventData));
        }

        [Fact]
        public async Task Provider_WhenJsonConversionFails_ShouldThrowException()
        {
            // Arrange
            string jsonEventData = "{\"NotificationType\":\"Email\",\"OtherField\":\"value\"}";
            byte[] eventData = Encoding.UTF8.GetBytes(jsonEventData);
            var cloudEventData = new BinaryData(eventData);

            _mockKeyedServiceProvider.Setup(x => x.GetRequiredKeyedService(typeof(INotificationFactory), NotificationType.Email)).Returns(_mockNotificationFactory.Object);

            _mockNotificationFactory.Setup(factory => factory.ConvertToObject(It.IsAny<BinaryData>()))
                .Throws(new Exception("Conversion error"));

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => _notificationServiceProvider.GetServiceAsync(cloudEventData));
        }

        [Fact]
        public async Task GetServiceAsync_WhenNotificationSendFails_ShouldReturnFailureResponse()
        {
            // Arrange
            string jsonEventData = "{\"NotificationType\":\"Email\",\"OtherField\":\"value\"}";
            byte[] eventData = Encoding.UTF8.GetBytes(jsonEventData); 
            var cloudEventData = new BinaryData(eventData); 

            var expectedResponse = new NotificationResponseModel(500, false, string.Empty);

            _mockKeyedServiceProvider.Setup(x => x.GetRequiredKeyedService(typeof(INotificationFactory), NotificationType.Email)).Returns(_mockNotificationFactory.Object);

            _mockNotificationFactory.Setup(factory => factory.ConvertToObject(It.IsAny<BinaryData>()))
                .Returns(It.IsAny<INotificationRequestModel>());

            _mockNotificationFactory.Setup(factory => factory.BuildAndSendNotificationAsync(It.IsAny<INotificationRequestModel>()))
                .ReturnsAsync(expectedResponse);

            // Act
            var result = await _notificationServiceProvider.GetServiceAsync(cloudEventData);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccessStatusCode);
        }
    }
}
