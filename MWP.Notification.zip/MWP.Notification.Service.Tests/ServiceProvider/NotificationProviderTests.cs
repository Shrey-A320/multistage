﻿namespace MWP.Notification.Service.Tests.ServiceProvider
{
    public class NotificationProviderTests
    {
        private readonly Mock<ICosmosDbRepository> _mockCosmosDbRepository;
        private readonly Mock<IMapper> _mockMapper;
        private readonly Mock<ILogger<NotificationProvider>> _mockLogger;
        private readonly NotificationProvider _notificationProvider;

        public NotificationProviderTests()
        {
            _mockCosmosDbRepository = new Mock<ICosmosDbRepository>();
            _mockMapper = new Mock<IMapper>();
            _mockLogger = new Mock<ILogger<NotificationProvider>>();
            _notificationProvider = new NotificationProvider(_mockLogger.Object, _mockMapper.Object, _mockCosmosDbRepository.Object);
        }

        [Fact]
        public async Task SaveNotificationAsync_ShouldCreateRecord()
        {
            var notificationResponseModel = new NotificationResponseModel(400, false, "Bad request");

            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();

            _mockCosmosDbRepository
            .Setup(client => client.AddRecords(It.IsAny<object>())).
            ReturnsAsync(true);

            // Act
            await _notificationProvider.SaveNotificationAsync(notificationResponseModel, emailRequestModel);

            // Assert
            _mockCosmosDbRepository.Verify(client => client.AddRecords(
                It.IsAny<object>()
            ), Times.Once);

        }

        [Fact]
        public async Task SaveNotificationAsync_ShouldThrowException_WhenRecordCreationFails()
        {
            //Arrange
            var notificationResponseModel = new NotificationResponseModel(400, false, "Bad request");

            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .Build();

            _mockCosmosDbRepository
            .Setup(client => client.AddRecords(It.IsAny<object>())).
            Throws(new Exception("Record creation failed"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _notificationProvider.SaveNotificationAsync(notificationResponseModel, emailRequestModel));

        }
    }
}
