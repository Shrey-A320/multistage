﻿namespace MWP.Notification.Service.Tests.Factories
{
    public class EmailServiceTests
    {
        private readonly Mock<IEmailSender> _mockEmailSender;
        private readonly Mock<INotificationProvider> _notificationProvider;
        private readonly Mock<ILogger<EmailService>> _mockLogger;
        private readonly Mock<IOptions<NotificationConfiguration>> _mockEmailSettings;
        private readonly EmailService _emailService;

        public EmailServiceTests()
        {
            _mockEmailSender = new Mock<IEmailSender>();
            _notificationProvider = new Mock<INotificationProvider>();
            _mockLogger = new Mock<ILogger<EmailService>>();
            _mockEmailSettings = new Mock<IOptions<NotificationConfiguration>>();
            _mockEmailSettings.Setup(x => x.Value).Returns(new NotificationConfiguration
            {
                FromAddress = "test@example.com"
            });
            _emailService = new EmailService(_mockEmailSender.Object, _mockLogger.Object, _mockEmailSettings.Object, _notificationProvider.Object);
        }

        [Fact]
        public async Task BuildAndSendNotificationAsync_ValidRequest_ReturnsSuccessResponse()
        {
            // Arrange
            var EmailHeader = new EmailHeader
            {
                Sender = "TestUser",
                SenderName = "Test",
                Subject = "Test Subject",
                Body = "Test Body",
                To = new List<string> { "to1@example.com", "to2@example.com" },
                Cc = new List<string> { "cc@example.com" },
                Bcc = new List<string> { "bcc@example.com" }
            };

            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithContext("Test")
            .WithEmailHeader(EmailHeader)
            .Build();

            var expectedResponse = new NotificationResponseModel(202, true, string.Empty);


            _mockEmailSender.Setup(sender => sender.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
                            .ReturnsAsync(expectedResponse);
            _notificationProvider.Setup(provider => provider.SaveNotificationAsync(expectedResponse, It.IsAny<object>()))
                .Returns(Task.CompletedTask);

            // Act
            var result = await _emailService.BuildAndSendNotificationAsync(emailRequestModel);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccessStatusCode);

            _mockEmailSender.Verify(sender => sender.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()), Times.Once);
            _notificationProvider.Verify(sender => sender.SaveNotificationAsync(expectedResponse, It.IsAny<object>()), Times.Once);

        }

        [Fact]
        public async Task BuildAndSendNotificationAsync_ValidRequestWithAttachments_ReturnsSuccessResponse()
        {
            // Arrange
            var EmailHeader = new EmailHeader
            {
                Sender = "TestUser",
                SenderName = "Test",
                Subject = "Test Subject",
                Body = "Test Body",
                To = new List<string> { "to1@example.com", "to2@example.com" },
                Cc = new List<string> { "cc@example.com" },
                Bcc = new List<string> { "bcc@example.com" }
            };

            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .WithNotificationType(NotificationType.Email)
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithContext("Test")
            .WithEmailHeader(EmailHeader)
            .WithAttachments(new List<string> { "attachment1.csv", "attachment2.csv" })
            .Build();

            var expectedResponse = new NotificationResponseModel(202, true, string.Empty);

            _mockEmailSender.Setup(sender => sender.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
                            .ReturnsAsync(expectedResponse);
            _notificationProvider.Setup(provider => provider.SaveNotificationAsync(expectedResponse, It.IsAny<object>()))
            .Returns(Task.CompletedTask);

            // Act
            var result = await _emailService.BuildAndSendNotificationAsync(emailRequestModel);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccessStatusCode);

            _mockEmailSender.Verify(sender => sender.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()), Times.Once);
            _notificationProvider.Verify(sender => sender.SaveNotificationAsync(expectedResponse, It.IsAny<object>()), Times.Once);

        }

        [Fact]
        public async Task BuildAndSendNotificationAsync__WhenEmailSendingFails_ShouldThrowException()
        {
            // Arrange
            var EmailHeader = new EmailHeader
            {
                Sender = "TestUser",
                SenderName = "Test",
                Subject = "Test Subject",
                Body = "Test Body",
                To = new List<string> { "to1@example.com", "to2@example.com" },
                Cc = new List<string> { "cc@example.com" },
                Bcc = new List<string> { "bcc@example.com" }
            };

            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithContext("Test")
            .WithEmailHeader(EmailHeader)
            .WithAttachments(new List<string> { "attachment1.csv", "attachment2.csv" })
            .Build();


            var expectedResponse = new NotificationResponseModel(202, true, string.Empty);
            var exceptionMessage = "Email sending failed.";
            _mockEmailSender.Setup(sender => sender.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
                            .ThrowsAsync(new Exception(exceptionMessage));
            _notificationProvider.Setup(provider => provider.SaveNotificationAsync(expectedResponse, It.IsAny<object>()))
            .Returns(Task.CompletedTask);

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() => _emailService.BuildAndSendNotificationAsync(emailRequestModel));
            _mockLogger.Verify(
                    x => x.Log(
                    It.Is<LogLevel>(l => l == LogLevel.Error),
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => true),
                    It.IsAny<Exception>(),
                    It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)), Times.Once);
        }

        [Fact]
        public async Task BuildAndSendNotificationAsync_WhenEmailRequestIsInvalid_ShouldReturnError()
        {
            // Arrange
            var EmailHeader = new EmailHeader
            {
                Sender = "TestUser",
                SenderName = "Test",
                Subject = "Test Subject",
                Body = "Test Body",
                To = new List<string> { "Test@gmail.com" },
                Cc = new List<string> { "cc@example.com" },
                Bcc = new List<string> { "bcc@example.com" }
            };

            var emailRequestModel = new EmailRequestModelTestBuilder()
            .WithSource(NotificationSource.Process)
            .WithNotificationType(NotificationType.Email)
            .WithCorrelationId(new Guid(Guid.NewGuid().ToString()))
            .WithNotificationSeverity(NotificationSeverity.Warning)
            .WithEmailProvider(EmailProvider.SendGrid)
            .WithCreatedOn(DateTime.Now)
            .WithCreatedBy("11021")
            .WithContext("Test")
            .WithEmailHeader(EmailHeader)
            .WithAttachments(new List<string> { "attachment1.csv", "attachment2.csv" })
            .Build();

            var expectedResponse = new NotificationResponseModel(500, false, "Email request is invalid");

            // Simulate an invalid email request scenario
            _mockEmailSender.Setup(sender => sender.SendEmailAsync(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<string>>(), It.IsAny<string>()))
                            .ReturnsAsync(expectedResponse);
            _notificationProvider.Setup(provider => provider.SaveNotificationAsync(expectedResponse, It.IsAny<object>()))
            .Returns(Task.CompletedTask);

            // Act
            var result = await _emailService.BuildAndSendNotificationAsync(emailRequestModel);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.IsSuccessStatusCode);
            Assert.Equal("Email request is invalid", result.ErrorMessage);

            _notificationProvider.Verify(sender => sender.SaveNotificationAsync(expectedResponse, It.IsAny<object>()), Times.Once);
        }
    }
}
