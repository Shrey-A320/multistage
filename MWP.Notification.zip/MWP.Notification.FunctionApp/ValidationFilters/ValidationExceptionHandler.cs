﻿namespace MWP.Notification.FunctionApp.ValidationFilters
{
    public class ValidationExceptionHandler : IFunctionsWorkerMiddleware
    {
        private readonly ILogger<ValidationExceptionHandler> _logger;

        public ValidationExceptionHandler(ILogger<ValidationExceptionHandler> logger)
        {
            _logger = logger;
        }

        public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (ValidationException ex)
            {
                _logger.LogError($"Validation error occurred: {ex.Message}");
                LogEventError(context, "Validation error", ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error occurred: {ex.Message}");
                LogEventError(context, "Unexpected error", ex.Message);
            }
        }

        private void LogEventError(FunctionContext context, string errorType, string errorMessage)
        {
            _logger.LogError($"Error Type: {errorType}, Message: {errorMessage}");
        }
    }
}
