// Default URL for triggering event grid function in the local environment.
// http://localhost:7071/runtime/webhooks/EventGrid?functionName={functionname}
namespace MWP.Notification.FunctionApp
{
    /// <summary>
    /// Azure Function that processes EventGrid events, logs event details such as type and subject.
    /// Triggered by EventGrid events using <see cref="EventGridTrigger"/> and logs the event's type and subject.
    /// </summary>
    public class NotificationFunction
    {
        private readonly ILogger<NotificationFunction> _logger;
        private readonly INotificationServiceProvider _notificationTypeProvider;

        public NotificationFunction(ILogger<NotificationFunction> logger, INotificationServiceProvider notificationTypeProvider)
        {
            _logger = logger;
            _notificationTypeProvider = notificationTypeProvider;
        }

        /// <summary>
        /// Handles incoming EventGrid events by logging the event type and subject.
        /// Triggered by an EventGrid event and logs the event details using <see cref="ILogger"/>.
        /// </summary>
        /// <param name="cloudEvent">The EventGrid event that triggers the function, containing event details such as type and subject.</param>
        [Function(nameof(NotificationFunction))]
        public async Task<ActionResult<NotificationResponseModel>> Run([EventGridTrigger] CloudEvent cloudEvent)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            _logger.LogInformation("Event type: {type}, Event subject: {subject}, Start time: {starttime}", cloudEvent.Type, cloudEvent.Subject, sw.ElapsedMilliseconds);
            
            var response = await _notificationTypeProvider.GetServiceAsync(cloudEvent.Data);
            sw.Stop();
            _logger.LogInformation("Stop time: {stoptime}", sw.ElapsedMilliseconds);
            return new OkObjectResult(response);
        }
    }
}
