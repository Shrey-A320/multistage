var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices((context, services) =>
    {
        services
        .RegisterService(context.Configuration)
        .RegisterKeyedServices(context.Configuration)
        .AddMwpLogging(context.HostingEnvironment);
        services.AddHttpContextAccessor();

        if (!context.HostingEnvironment.IsDevelopment())
        {
            services.AddApplicationInsightsTelemetryWorkerService();
        }
    })
    .ConfigureAppConfiguration((context, config) =>
    {
        if (context.HostingEnvironment.IsDevelopment())
        {
            config.AddJsonFile("local.settings.json");
            config.AddUserSecrets<Program>();
        }
    })
    .ConfigureLogging((builder) =>
    {
        builder.AddApplicationInsights();
    })
    .Build();

host.Run();

[ExcludeFromCodeCoverage]
public partial class Program
{ }