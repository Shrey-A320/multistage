﻿namespace MWP.Notification.FunctionApp
{
    /// <summary>
    /// Contains extension methods for configuring services in the MWP Notification FunctionApp.
    /// </summary>
    [ExcludeFromCodeCoverage]

    public static class ConfigureServices
    {
        /// <summary>
        /// Registers core services required for the application.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection"/> to register services with.</param>
        /// <param name="configuration">The <see cref="IConfiguration"/> application settings.</param>
        /// <returns>The updated <see cref="IServiceCollection"/>.</returns>
        /// <exception cref="ApplicationException">Thrown exception.</exception>
        public static IServiceCollection RegisterService(this IServiceCollection services, IConfiguration configuration)
        {
            // Register JsonSerializerOptions as a singleton
            services.AddSingleton(new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            });

            var jsonSerializerOptions = new JsonSerializerOptions
            {
                Converters = { new JsonStringEnumConverter() }
            };

            services.Configure<WorkerOptions>(options =>
            {
                options.Serializer = new JsonObjectSerializer(jsonSerializerOptions);
            });

            // Add scoped services
            services.AddScoped<IBlobStorageService, BlobStorageService>();
            services.AddScoped<IEmailSender, EmailSender>();
            services.AddScoped<INotificationServiceProvider, NotificationServiceProvider>();
            services.AddScoped<INotificationProvider, NotificationProvider>();

            // Add AutoMapper
            services.AddAutoMapper(typeof(NotificationProfile));

            var sendGridApiKey = configuration.GetValue<string>("SendGridApiKey");

            var config = configuration.Get<NotificationConfiguration>() ?? throw new ApplicationException("Application's configuration not found.");

            // Register SendGrid
            services.AddSendGrid(options =>
            {
                options.ApiKey = config.SendGridApiKey;
            });

            // Configure Cosmos DB
            var cosmosClientOptions = new CosmosClientOptions { ApplicationName = config.FunctionName };
            var cosmosClient = new CosmosClient(config.CosmosConnectionString, cosmosClientOptions);
            var cosmosConfig = new CosmosDbSettings(
                config.CosmosDatabaseId,
                config.CosmosConnectionString,
                config.CosmosContainerId
            );

            services.AddSingleton<IAzureContextManager>(provider =>
            {
                var logger = provider.GetRequiredService<ILogger<AzureContextManager>>();
                return new AzureContextManager(
                    cosmosClient,
                    cosmosConfig,
                    config.BlobConnectionString,
                    config.BlobContainerName,
                    logger
                );
            });

            services.AddSingleton<ICosmosDbRepository>(provider =>
            {
                var contextManager = provider.GetRequiredService<IAzureContextManager>();
                var logger = provider.GetRequiredService<ILogger<CosmosDbRepository>>();
                return new CosmosDbRepository(contextManager, cosmosConfig, logger);
            });

            // Initialize Cosmos DB
            services.BuildServiceProvider()
                    .GetRequiredService<IAzureContextManager>()
                    .InitializeAsync();

            return services;
        }

        public static IServiceCollection AddMwpLogging(this IServiceCollection services, IHostEnvironment environment)
        {
            services.AddHttpContextAccessor();

            if (!environment.IsDevelopment())
            {
                services.AddApplicationInsightsTelemetryWorkerService();
            }

            services.AddHeaderPropagation(options =>
                options.Headers.Add(CommonConstants.CorrelationIdHeaderName, context =>
                    (bool)(context.HttpContext?.Request.Headers.TryGetValue(CommonConstants.CorrelationIdHeaderName, out var correlationId))
                        ? correlationId.FirstOrDefault()
                        : Guid.NewGuid().ToString()));

            services.AddSingleton<CorrelationIdMiddleware>();

            return services;
        }

        /// <summary>
        /// Registers keyed services for specific notification types.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection"/> to register services with.</param>
        /// <param name="configuration">The <see cref="IConfiguration"/> application settings.</param>
        /// <returns>The updated <see cref="IServiceCollection"/>.</returns>
        public static IServiceCollection RegisterKeyedServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddKeyedScoped<INotificationFactory, EmailService>(NotificationType.Email);
            return services;
        }
    }
}
