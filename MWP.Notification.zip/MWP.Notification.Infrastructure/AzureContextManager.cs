﻿namespace MWP.Notification.Infrastructure
{
    /// <summary>
    /// Provides methods for managing interactions with Azure services by instantiating it here.
    /// Implements <see cref="IAzureContextManager"/>.
    /// </summary>
    public class AzureContextManager : IAzureContextManager
    {
        private readonly BlobContainerClient _blobContainerClient;

        private readonly CosmosClient _notificationDbClient;
        private readonly CosmosDbSettings _notificationDbSettings;
        private readonly ILogger<AzureContextManager> _logger;

        public AzureContextManager(CosmosClient notificationDbClient, CosmosDbSettings notificationDbSettings, string blobConnectionString, string blobContainerName,ILogger<AzureContextManager> logger)
        {
            _notificationDbClient = notificationDbClient;
            _notificationDbSettings = notificationDbSettings;
            _blobContainerClient = new BlobContainerClient(blobConnectionString, blobContainerName);
            _logger = logger;
        }

        ///<inheritdoc/>
        public async Task<BlobContainerClient> InitializeContainerClientAsync()
        {
            try
            {
                // Ensure the container exists, this is asynchronous
                await _blobContainerClient.CreateIfNotExistsAsync();
                return _blobContainerClient;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while creating the conatiner", ex);
            }
        }

        ///<inheritdoc/>
        public Container GetCosmosContainerClient(string databaseId, string containerId)
        {
            try
            {
                return _notificationDbClient.GetContainer(databaseId, containerId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while fetching the reference to the container", ex);
            }
        }

        public async Task InitializeAsync()
        {
            try
            {
                await CreateDatabaseAsync();
                await CreateContainerAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while creating database and container", ex);
            }
        }

        public async Task CreateDatabaseAsync()
        {
            try
            {
                await _notificationDbClient.CreateDatabaseIfNotExistsAsync(_notificationDbSettings.CosmosDbDatabaseID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while creating database", ex);
            }
        }

        public async Task CreateContainerAsync()
        {
            try
            {
                var database = _notificationDbClient.GetDatabase(_notificationDbSettings.CosmosDbDatabaseID);
                await database.CreateContainerIfNotExistsAsync(_notificationDbSettings.CosmosDbContainerID, _notificationDbSettings.CosmosDbPartitionKey);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while creating container", ex);
            }
        }
    }
}
