﻿namespace MWP.Notification.Infrastructure.Models
{
    public class NotificationDataItem
    {
        public string id { get; set; }

        public string Context { get; set; }

        public string CorrelationId { get; set; }

        public string CreatedBy { get; set; }

        public string CreatedOn { get; set; }
        public string PartitionKey => CreatedOn;

        public NotificationData Data { get; set; }

        public string NotificationType { get; set; }

        public string Severity { get; set; }

        public string Status { get; set; }
    }

    public class NotificationData
    {
        public string Body { get; set; }
        public NotificationDataHeader Header { get; set; }
        public EmailServiceResponse Response { get; set; }
        public string Source { get; set; }
    }

    public class NotificationDataHeader
    {
        public string Sender { get; set; }
        public string SenderName { get; set; }
        public List<string> To { get; set; }
        public List<string> Cc { get; set; } = new List<string>();
        public List<string> Bcc { get; set; } = new List<string>();
        public string Subject { get; set; }
    }

    public class EmailServiceResponse
    {
        public string StatusCode { get; set; }
        public string IsSuccessStatusCode { get; set; }
        public string ErrorMessage { get; set; }
    }

}