﻿namespace MWP.Notification.Infrastructure.Repositories
{
    public class CosmosDbRepository : ICosmosDbRepository
    {
        private readonly IAzureContextManager _azureContextManager;
        private readonly CosmosDbSettings _notificationDbSettings;
        private readonly ILogger<CosmosDbRepository> _logger;


        public CosmosDbRepository(IAzureContextManager azureContextManager, CosmosDbSettings notificationDbSettings, ILogger<CosmosDbRepository> logger)
        {
            _azureContextManager = azureContextManager;
            _notificationDbSettings = notificationDbSettings;
            _logger = logger;
        }


        public async Task<bool> AddRecords<T>(T parameters)
        {
            try
            {
                return await AddItemsToContainerAsync(parameters, _notificationDbSettings.CosmosDbDatabaseID, _notificationDbSettings.CosmosDbContainerID);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while adding records in the cosmos db.", ex);
            }
        }

        public async Task<bool> AddItemsToContainerAsync<T>(T paramters, string databaseId, string containerId)
        {
            try
            {
                var notificationMessageContainer = _azureContextManager.GetCosmosContainerClient(databaseId, containerId);
                await notificationMessageContainer.CreateItemAsync(paramters);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while adding items in the conatiner", ex);
            }
        }


    }
}
