﻿namespace MWP.Notification.Infrastructure.Interfaces
{
    public interface ICosmosDbRepository
    {
        Task<bool> AddRecords<T>(T parameters);
        Task<bool> AddItemsToContainerAsync<T>(T parameters, string databaseId, string containerId);

    }
}
