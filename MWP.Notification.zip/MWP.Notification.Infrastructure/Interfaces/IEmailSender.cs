﻿namespace MWP.Notification.Infrastructure.Interfaces
{
    public interface IEmailSender
    {
        /// <summary>
        /// Uses to send email 
        /// </summary>
        /// <param name="fromAddress">The from address of the email</param>
        /// <param name="toAddress">The to address of the email (Semi-colon separated list of emails)</param>
        /// <param name="subject">The subject line of the email</param>
        /// <param name="messageBody">The body of the email</param>
        /// <param name="attachmentKeys">The attachment keys to build email attachments</param>
        Task<NotificationResponseModel> SendEmailAsync(string fromAddress, string toAddress, string subject, string messageBody, List<string> attachmentKeys, string folderName);

        /// <summary>
        /// Send email with cc
        /// </summary>
        /// <param name="fromAddress">The Sender address of the email</param>
        /// <param name="toAddress">The To address of the email (Semi-colon separated list of emails)</param>
        /// <param name="ccAddress">The CC address of the email (Semi-colon separated list of emails)</param>
        /// <param name="subject">The subject line of the email</param>
        /// <param name="messageBody">The body of the email</param>
        /// <param name="attachmentKeys">The attachment keys to build email attachments</param>
        /// <returns></returns>
        Task<NotificationResponseModel> SendEmailAsync(string fromAddress, string toAddress, string ccAddress, string subject, string messageBody, List<string> attachmentKeys, string folderName);


        /// <summary>
        /// Send email with cc and Bcc
        /// </summary>
        /// <param name="fromAddress">The Sender address of the email</param>
        /// <param name="toAddress">The To address of the email (Semi-colon separated list of emails)</param>
        /// <param name="ccAddress">The CC address of the email (Semi-colon separated list of emails)</param>
        /// <param name="bccAddress">The BCC address of the email (Semi-colon separated list of emails)</param>
        /// <param name="subject">The subject line of the email</param>
        /// <param name="messageBody">The body of the email</param>
        /// <param name="attachmentKeys">The attachment keys to build email attachments</param>
        /// <returns></returns>
        Task<NotificationResponseModel> SendEmailAsync(string fromAddress, string toAddress, string ccAddress, string bccAddress, string subject, string messageBody, List<string> attachmentKeys, string folderName);
    }
}
