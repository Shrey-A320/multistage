﻿namespace MWP.Notification.Infrastructure.Interfaces
{
    public interface IAzureContextManager
    {
        /// <summary>
        /// Initializes and ensures the existence of the specified BlobContainerClient asynchronously. 
        /// If the container does not exist, it will be created.
        /// </summary>
        /// <returns>Returns an instance of the <see cref="BlobContainerClient"/>.</returns>
        Task<BlobContainerClient> InitializeContainerClientAsync();
        Container GetCosmosContainerClient(string databaseId, string containerId);
        Task InitializeAsync();
        Task CreateDatabaseAsync();
        Task CreateContainerAsync();
    }
}
