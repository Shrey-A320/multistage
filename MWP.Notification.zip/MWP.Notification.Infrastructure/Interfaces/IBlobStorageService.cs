﻿namespace MWP.Notification.Infrastructure.Interfaces
{
    public interface IBlobStorageService
    {
        /// <summary>
        /// Downloads the specified blob from the given Azure Blob Storage container and folder, and retrieves its metadata.
        /// </summary>
        /// <param name="folderName">The folder path within the container.</param>
        /// <param name="blobName">The name of the blob to download.</param>
        /// <returns>Returns a <see cref="BlobMetaData"/> object containing the downloaded data and metadata.</returns>
        /// <exception cref="FileNotFoundException">Thrown when the blob is not found or returns empty data.</exception>
        /// <exception cref="InvalidOperationException">Thrown for unexpected errors during blob download.</exception>
        Task<BlobMetaData> GetAsync(string folderName, string blobName);
    }
}
