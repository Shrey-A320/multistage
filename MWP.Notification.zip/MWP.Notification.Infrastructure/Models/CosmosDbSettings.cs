﻿namespace MWP.Notification.Infrastructure.Models
{
    /// <summary>
    /// Represents a model containing database Id and connection string
    /// </summary>
    public class CosmosDbSettings
    {
        /// <summary>
        /// Gets or sets the CosmosDbDatabaseID of the Cosmos Database.
        /// </summary>
        public string CosmosDbDatabaseID { get; set; }
        /// <summary>
        /// Gets or sets the CosmosDbConnectionString of the Cosmos Database.
        /// </summary>
        public string CosmosDbConnectionString { get; set; }
        /// <summary>
        /// Gets or sets the CosmosDbContainerID of the Cosmos Database.
        /// </summary>
        public string CosmosDbContainerID { get; set; }
        /// <summary>
        /// Gets or sets the CosmosDbPartitionKey of the Cosmos Database.
        /// </summary>
        public string CosmosDbPartitionKey { get; set; }

        public CosmosDbSettings(string databaseId,string connString, string cosmosDbContainerID, string cosmosDbPartitionKey = "/PartitionKey")
        {
            CosmosDbConnectionString = connString;
            CosmosDbDatabaseID = databaseId;
            CosmosDbContainerID = cosmosDbContainerID;
            CosmosDbPartitionKey = cosmosDbPartitionKey;
        }
    }
}
