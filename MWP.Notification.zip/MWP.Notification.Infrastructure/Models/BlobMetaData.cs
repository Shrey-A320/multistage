﻿namespace MWP.Notification.Infrastructure.Models
{
    /// <summary>
    /// Represents metadata for a blob download operation, including the success status, downloaded data, and any related messages.
    /// </summary>
    public class BlobMetaData
    {
        /// <summary>
        /// Indicates whether the blob download operation was successful.
        /// </summary>
        public bool IsSuccessful { get; set; } = false;

        /// <summary>
        /// Contains the data downloaded from the blob as a byte array.
        /// </summary>
        public byte[] DownloadedData { get; set; }

        /// <summary>
        /// A message providing additional information about the download operation (e.g., error messages or status).
        /// </summary>
        public string Message { get; set; }
    }
}
