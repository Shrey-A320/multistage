﻿namespace MWP.Notification.Infrastructure
{
    public class EmailSender : IEmailSender
    {
        private readonly IBlobStorageService _azureBlobStorageService;
        private readonly ILogger<EmailSender> _logger;
        private readonly ISendGridClient _client;

        public EmailSender(IBlobStorageService azureBlobStorageService, ILogger<EmailSender> logger, ISendGridClient client)
        {
            _azureBlobStorageService = azureBlobStorageService;
            _logger = logger;
            _client = client;
        }

        ///<inheritdoc/>
        public async Task<NotificationResponseModel> SendEmailAsync(string fromAddress, string toAddress, string subject, string body, List<string> attachmentKeys, string folderName)
        {
            return await SendEmailAsync(fromAddress, toAddress, string.Empty, subject, body, attachmentKeys, folderName);
        }

        ///<inheritdoc/>
        public async Task<NotificationResponseModel> SendEmailAsync(string fromAddress, string toAddress, string ccAddress, string subject, string body, List<string> attachmentKeys, string folderName)
        {
            return await SendEmailAsync(fromAddress, toAddress, ccAddress, string.Empty, subject, body, attachmentKeys, folderName);
        }

        ///<inheritdoc/>
        public async Task<NotificationResponseModel> SendEmailAsync(string fromAddress, string toAddress, string ccAddress, string bccAddress, string subject, string body, List<string> attachmentKeys, string folderName)
        {
            var from = new EmailAddress(fromAddress);
            var toEmails = GetEmailFromString(toAddress);
            var ccEmails = GetEmailFromString(ccAddress);
            var bccEmails = GetEmailFromString(bccAddress);

            ValidateAtLeastOneEmailIsAvailable(toEmails, ccEmails, bccEmails);

            var msg = MailHelper.CreateSingleEmailToMultipleRecipients(from, toEmails, subject, body, body);
            msg.ReplyTo = from;

            ccEmails.ForEach(i => msg.AddCc(i));
            bccEmails.ForEach(i => msg.AddBcc(i));

            if (attachmentKeys?.Count > 0)
                await BuildAttachments(msg, attachmentKeys, folderName);

            return await InvokeMail(msg);
        }

        /// <summary>
        /// Converts a semicolon-separated string of email addresses into a list of EmailAddress objects.
        /// </summary>
        /// <param name="emailString">String of email addresses separated by semicolons.</param>
        /// <returns>List of EmailAddress objects.</returns>
        private List<EmailAddress> GetEmailFromString(string emailString)
        {
            return emailString != null && emailString.Length > 0 ? new List<EmailAddress>(emailString.Split(';')
            .Select((email) => new EmailAddress(email))) : new List<EmailAddress>();
        }

        /// <summary>
        /// Ensures that at least one email address is provided in the To, CC, or BCC fields.
        /// </summary>
        /// <param name="toEmails">List of To email addresses.</param>
        /// <param name="ccEmails">List of CC email addresses.</param>
        /// <param name="bccEmails">List of BCC email addresses.</param>
        private void ValidateAtLeastOneEmailIsAvailable(List<EmailAddress> toEmails, List<EmailAddress> ccEmails, List<EmailAddress> bccEmails)
        {
            if (toEmails.Count == 0 && ccEmails.Count == 0 && bccEmails.Count == 0)
            {
                throw new ArgumentNullException("To, Cc, and Bcc email addresses are empty. There are no email addresses to send this email to.");
            }
        }

        /// <summary>
        /// Retrieves attachments from Azure Blob Storage and adds them to the email message.
        /// </summary>
        /// <param name="msg">SendGrid message.</param>
        /// <param name="attachmentKeys">List of attachment keys.</param>
        /// <param name="bucketName">Name of the container for attachments.</param>
        private async Task BuildAttachments(SendGridMessage msg, List<string> attachmentKeys, string folderName)
        {
            foreach (string attachmentKey in attachmentKeys)
            {
                var data = await _azureBlobStorageService.GetAsync(folderName, attachmentKey);
                if (data != null)
                {
                    msg.AddAttachment(attachmentKey, Convert.ToBase64String(data.DownloadedData));
                }
            }
        }

        /// <summary>
        /// Sends the email message using the SendGrid client and handles the response.
        /// </summary>
        /// <param name="msg">SendGrid message.</param>
        /// <returns>Notification response model.</returns>
        private async Task<NotificationResponseModel> InvokeMail(SendGridMessage msg)
        {
            try
            {
                var response = await _client.SendEmailAsync(msg);

                if (response == null || response?.StatusCode != HttpStatusCode.Accepted)
                {
                    _logger.LogError($"Call to SendGrid Api failed with error code - {response?.StatusCode}");
                    throw new HttpRequestException($"Response - {response?.StatusCode}");
                }

                return new NotificationResponseModel((int)response?.StatusCode, response.IsSuccessStatusCode, "");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                throw;
            }
        }
    }
}
