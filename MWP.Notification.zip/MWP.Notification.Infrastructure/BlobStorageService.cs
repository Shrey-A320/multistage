﻿namespace MWP.Notification.Infrastructure
{
    /// <summary>
    /// Provides functionality to interact with Azure Blob Storage, including downloading blobs and retrieving their metadata.
    /// Implements <see cref="IBlobStorageService"/>.
    /// </summary>
    public class BlobStorageService : IBlobStorageService
    {
        private readonly ILogger<BlobStorageService> _logger;
        private readonly IAzureContextManager _azureContextManager;

        public BlobStorageService(ILogger<BlobStorageService> logger, IAzureContextManager azureContextManager)
        {
            _logger = logger;
            _azureContextManager = azureContextManager;
        }

        ///<inheritdoc/>
        public async Task<BlobMetaData> GetAsync(string folderName, string blobName)
        {
            BlobMetaData blobMetaData = new BlobMetaData();
            try
            {
                var blobContainerClient = await _azureContextManager.InitializeContainerClientAsync();
                var blobClient = blobContainerClient.GetBlobClient($"{folderName}/{blobName}");

                using (var stream = new MemoryStream())
                {
                    await blobClient.DownloadToAsync(stream);
                    blobMetaData.DownloadedData = stream.ToArray();
                    blobMetaData.IsSuccessful = true;
                }

                if (blobMetaData.DownloadedData == null || blobMetaData.DownloadedData.Length == 0)
                {
                    _logger.LogWarning($"[GetAsync]: Blob not found or returned empty data for blob: {folderName}/{blobName}");
                    throw new FileNotFoundException($"Blob '{blobName}' not found in folder '{folderName}'. The blob metadata is null.");
                }

                return blobMetaData;
            }
            catch (FileNotFoundException ex)
            {
                _logger.LogError($"FileNotFoundException: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Unexpected error: {ex.Message}, StackTrace: {ex.StackTrace}");
                throw new InvalidOperationException($"An unexpected error occurred while downloading the blob '{blobName}' from folder '{folderName}'", ex);
            }
        }
    }
}
