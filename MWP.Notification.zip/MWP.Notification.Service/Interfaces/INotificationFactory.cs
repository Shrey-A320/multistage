﻿namespace MWP.Notification.Service.Interfaces
{
    public interface INotificationFactory
    {
        /// <summary>
        /// Asynchronously builds and sends a notification.
        /// </summary>
        /// <param name="notificationRequestModel">The model containing notification request details.</param>
        /// <returns>NotificationResponseModel containing the result of the notification operation.</returns>
        Task<NotificationResponseModel> BuildAndSendNotificationAsync(INotificationRequestModel notificationRequestModel);

        /// <summary>
        /// Converts binary data into a notification request model.
        /// </summary>
        /// <param name="binaryData">The binary data to be converted into a notification request model.</param>
        /// <returns>An instance of INotificationRequestModel representing the notification request.</returns>
        INotificationRequestModel ConvertToObject(BinaryData binaryData);
    }
}
