﻿namespace MWP.Notification.Service.Interfaces
{
    public interface INotificationServiceProvider
    {
        /// <summary>
        /// Processes the incoming event data to determine the appropriate notification service        
        /// </summary>
        /// <param name="cloudEventData">The incoming event data containing details of the notification request, such as the notification type and other relevant data.</param>
        /// <returns>A task representing the asynchronous operation</returns>

        Task<NotificationResponseModel> GetServiceAsync(BinaryData cloudEventData);
    }
}
