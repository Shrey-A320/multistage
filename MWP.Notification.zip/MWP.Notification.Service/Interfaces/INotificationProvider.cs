﻿using MWP.Notification.Infrastructure.Models;

namespace MWP.Notification.Service.Interfaces
{
    public interface INotificationProvider
    {
        Task SaveNotificationAsync<T>(NotificationResponseModel emailResponse, T model);
    }
}
