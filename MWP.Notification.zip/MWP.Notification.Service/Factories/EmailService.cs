﻿namespace MWP.Notification.Service.Factories
{
    /// <summary>
    /// Asynchronously builds and sends an email notification based on the provided email request model.
    /// </summary>
    /// <param name="emailRequestModel">The model containing email request details, including recipient etc.</param>
    /// <returns>NotificationResponseModel indicating the result of sending the email.</returns>
    public class EmailService : NotificationService<EmailRequestModel>
    {
        private readonly IEmailSender _emailSender;
        private readonly INotificationProvider _notificationProvider;
        private readonly string _from;
        private NotificationResponseModel notificationResponseModel;

        public EmailService(IEmailSender emailSender, ILogger<EmailService> logger, IOptions<NotificationConfiguration> emailSettings, INotificationProvider notificationProvider)
        : base(logger)
        {
            _emailSender = emailSender;
            _from = emailSettings.Value.FromAddress;
            _notificationProvider = notificationProvider;
        }

        ///<inheritdoc/>
        public override async Task<NotificationResponseModel> BuildAndSendNotificationAsync(EmailRequestModel emailRequestModel)
        {

            var resultEmailRequest = new EmailRequestModelValidator().Validate(emailRequestModel);
            if (!resultEmailRequest.IsValid)
            {
                throw new ValidationException(resultEmailRequest.Errors.ToString());
            }
            var resultEmailHeader = new EmailHeaderValidator().Validate(emailRequestModel.EmailHeader);
            if (!resultEmailHeader.IsValid)
            {
                throw new ValidationException(resultEmailHeader.Errors.ToString());
            }
            try
            {
                notificationResponseModel = await _emailSender.SendEmailAsync(
                    _from,
                    emailRequestModel.EmailHeader.GetToEmailString(),
                    emailRequestModel.EmailHeader.GetCcEmailString(),
                    emailRequestModel.EmailHeader.GetBccEmailString(),
                    emailRequestModel.EmailHeader.Subject,
                    emailRequestModel.EmailHeader.Body,
                    emailRequestModel.Attachments,
                    emailRequestModel.FolderName
                );

                return notificationResponseModel;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception occurred while sending email: {ex.Message}, {ex.StackTrace}");
                throw;
            }
            finally
            {
                await _notificationProvider.SaveNotificationAsync(notificationResponseModel, emailRequestModel);
            }
        }
    }
}