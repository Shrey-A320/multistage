﻿namespace MWP.Notification.Service.AutoMapper
{
    public class NotificationProfile : Profile
    {
        public NotificationProfile()
        {
            CreateMap<(EmailRequestModel EmailModel, NotificationResponseModel RespModel), NotificationDataItem>()
                .ForMember(dest => dest.id, opt => opt.MapFrom(src => Guid.NewGuid().ToString()))
                .ForMember(dest => dest.CorrelationId, opt => opt.MapFrom(src => src.EmailModel.CorrelationId.ToString()))
                .ForMember(dest => dest.CreatedOn, opt => opt.MapFrom(src => DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss")))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.EmailModel.Audit ? "Success" : "Error"))
                .ForMember(dest => dest.Severity,opt => opt.MapFrom(src => nameof(src.EmailModel.Severity)))
                .ForMember(dest => dest.NotificationType,opt => opt.MapFrom(src => nameof(src.EmailModel.NotificationType)))
                .ForMember(dest => dest.Data, opt => opt.MapFrom(src => new NotificationData
                {
                    Body = src.EmailModel.EmailHeader.Body,
                    Header = new NotificationDataHeader
                    {
                        Sender = src.EmailModel.EmailHeader.Sender,
                        SenderName = src.EmailModel.EmailHeader.SenderName,
                        To = src.EmailModel.EmailHeader.To,
                        Cc = src.EmailModel.EmailHeader.Cc,
                        Bcc = src.EmailModel.EmailHeader.Bcc,
                        Subject = src.EmailModel.EmailHeader.Subject
                    },
                    Response = new EmailServiceResponse 
                    {
                        StatusCode = src.RespModel.StatusCode.ToString(),
                        IsSuccessStatusCode = src.RespModel.IsSuccessStatusCode.ToString(),
                        ErrorMessage = src.RespModel.ErrorMessage ?? string.Empty
                    },
                    Source = nameof(src.EmailModel.Source)
                }));
        }
    }
}
