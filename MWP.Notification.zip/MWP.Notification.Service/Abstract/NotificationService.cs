﻿namespace MWP.Notification.Service.Abstract
{
    /// <summary>
    /// Provides a base class for services that handle building and sending notifications.
    /// </summary>
    /// <typeparam name="T">The type of the notification request model, which must implement INotificationRequestModel.</typeparam>
    public abstract class NotificationService<T> : INotificationFactory where T : INotificationRequestModel
    {
        protected readonly ILogger _logger;

        protected NotificationService(ILogger logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Asynchronously builds and sends a notification based on the provided notification request model.
        /// </summary>
        /// <param name="notificationRequestModel">The model containing notification request details.</param>
        /// <returns>NotificationResponseModel indicating the result of sending the notification.</returns>
        public abstract Task<NotificationResponseModel> BuildAndSendNotificationAsync(T notificationRequestModel);

        ///<inheritdoc/>
        public INotificationRequestModel ConvertToObject(BinaryData binaryData)
        {
            var result = new BinaryDataValidator().Validate(binaryData);
            if (!result.IsValid)
            {
                throw new ValidationException(result.Errors.ToString());
            }
            try
            {
                return binaryData.ToObjectFromJson<T>();
            }
            catch (Exception ex)
            {
                throw new FormatException("Failed to convert binary data to notification request model.", ex);
            }
        }

        ///<inheritdoc/>
        Task<NotificationResponseModel> INotificationFactory.BuildAndSendNotificationAsync(INotificationRequestModel notificationRequestModel)
        {
            return BuildAndSendNotificationAsync((T)notificationRequestModel);
        }
    }
}
