﻿namespace MWP.Notification.Service.ServiceProvider
{
    public class NotificationProvider:INotificationProvider
    {
        private readonly ILogger<NotificationProvider> _logger;
        private readonly ICosmosDbRepository _cosmosDbService;
        private readonly IMapper _mapper;
        public NotificationProvider(ILogger<NotificationProvider> logger, IMapper mapper, ICosmosDbRepository cosmosDbService)
        {
            _logger = logger;
            _mapper = mapper;
            _cosmosDbService = cosmosDbService;
        }
        public async Task SaveNotificationAsync<T>(NotificationResponseModel emailResponse, T model)
        {
            try
            {
                var notificationTableItem = MapToNotificationEntity(emailResponse, model);

                await _cosmosDbService.AddRecords<NotificationDataItem>(notificationTableItem);

            }
            catch (Exception ex)
            {
                _logger.LogError($"Exception occurred while adding to Cosmos DB: {ex.Message}, {ex.StackTrace}");
                throw;
            }
        }

        private NotificationDataItem MapToNotificationEntity<T>(NotificationResponseModel emailResponse, T model)
        {
            var notificationDataItem = _mapper.Map<NotificationDataItem>((model, emailResponse));
            return notificationDataItem;
        }

    }
}