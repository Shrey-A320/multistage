﻿namespace MWP.Notification.Service.ServiceProvider
{
    /// <summary>
    /// Provides a service for handling notification requests based on EventGrid events.
    /// Retrieves the appropriate notification service using the notification type specified in the event data
    /// and sends the notification accordingly.
    /// </summary>
    public class NotificationServiceProvider : INotificationServiceProvider
    {
        private readonly ILogger<NotificationServiceProvider> _logger;
        private readonly IServiceProvider _keyedServiceProvider;

        public NotificationServiceProvider(ILogger<NotificationServiceProvider> logger, IServiceProvider keyedServiceProvider)
        {
            _logger = logger;
            _keyedServiceProvider = keyedServiceProvider;
        }

        ///<inheritdoc/>
        public async Task<NotificationResponseModel> GetServiceAsync(BinaryData cloudEventData)
        {
            try
            {
                var notificationType = cloudEventData.DeserializeToObject();

                // Use the NotificationType property
                var notificationFactory = _keyedServiceProvider.GetRequiredKeyedService<INotificationFactory>(notificationType);

                var notificationEventData = notificationFactory.ConvertToObject(cloudEventData);

                return await notificationFactory.BuildAndSendNotificationAsync(notificationEventData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred while processing the notification.");
                throw new InvalidOperationException("An error occurred while processing the notification.", ex);
            }
        }
    }
}
