﻿global using Microsoft.Extensions.Logging;
global using MWP.Notification.Domain;
global using MWP.Notification.Service.Interfaces;
global using Microsoft.Extensions.Options;
global using MWP.Notification.Common.Configurations;
global using MWP.Notification.Domain.EmailModels;
global using MWP.Notification.Infrastructure.Interfaces;
global using MWP.Notification.Service.Abstract;
global using MWP.Notification.Domain.Validators;
global using System.ComponentModel.DataAnnotations;
global using Microsoft.Extensions.DependencyInjection;
global using MWP.Notification.Domain.Extensions;
global using AutoMapper;
global using MWP.Notification.Infrastructure.Models;

