﻿namespace MWP.Notification.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum NotificationType
    {
        Email,
        Teams,
        Sms,
        PushNotification
    }
}
