﻿namespace MWP.Notification.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EmailProvider
    {
        SendGrid,
        ZenDesk
    }
}
