﻿namespace MWP.Notification.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum NotificationSeverity
    {
        Information,
        Warning,
        Error,
        Critical
    }
}
