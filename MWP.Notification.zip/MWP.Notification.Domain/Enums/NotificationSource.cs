﻿namespace MWP.Notification.Domain.Enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum NotificationSource
    {
        Process,
        User
    }
}
