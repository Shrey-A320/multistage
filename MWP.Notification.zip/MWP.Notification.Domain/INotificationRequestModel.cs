﻿namespace MWP.Notification.Domain
{
    /// <summary>
    /// Interface for notification request models.
    /// Defines the common properties required for all notification types.
    /// </summary>
    public interface INotificationRequestModel
    {

        public Guid CorrelationId { get; set; }
        public string Context { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public NotificationSource Source { get; set; }
        public NotificationType NotificationType { get; set; }
        public NotificationSeverity Severity { get; set; }
        public bool Audit { get; set; }
        public List<string> Attachments { get; set; }
    }
}
