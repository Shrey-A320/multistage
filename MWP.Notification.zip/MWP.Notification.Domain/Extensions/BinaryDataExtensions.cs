﻿using MWP.Notification.Common.Constants;

namespace MWP.Notification.Domain.Extensions
{
    /// <summary>
    /// Provides extension methods for working with <see cref="BinaryData"/>.
    /// Specifically, it contains a method to deserialize the binary data into a <see cref="NotificationType"/> enum
    /// based on the "NotificationType" property present in the JSON data.
    /// </summary>
    public static class BinaryDataExtensions
    {

        /// <summary>
        /// Deserializes the given <see cref="BinaryData"/> to extract the "NotificationType" value.
        /// </summary>
        /// <param name="cloudEventData">The binary data containing the event data in JSON format.</param>
        /// <returns>
        /// A <see cref="NotificationType"/> enum value representing the notification type extracted from the binary data.
        /// </returns>
        public static NotificationType DeserializeToObject(this BinaryData cloudEventData)
        {
            // Convert BinaryData to string (assuming it's in JSON format)
            var jsonString = cloudEventData.ToString();

            // Parse the JSON string and extract the NotificationType property
            using (var jsonDocument = JsonDocument.Parse(jsonString))
            {
                if (jsonDocument.RootElement.TryGetProperty(CommonConstants.NotificationType, out var notificationTypeProperty))
                {
                    var notificationTypeString = notificationTypeProperty.GetString();

                    // Try to parse it into NotificationType enum
                    if (Enum.TryParse(notificationTypeString, out NotificationType notificationType) &&
                        Enum.IsDefined(typeof(NotificationType), notificationType))
                    {
                        return notificationType;
                    }
                }
            }

            throw new InvalidOperationException($"Invalid or missing NotificationType: {jsonString}");
        }
    }
}
