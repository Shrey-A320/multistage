﻿namespace MWP.Notification.Domain.EmailModels
{
    /// <summary>
    /// Represents the header of an email, including sender details, recipients (To, Cc, Bcc), subject, and body.
    /// Provides methods to retrieve email addresses in string format for To, Cc, and Bcc fields.
    /// </summary>
    public class EmailHeader
    {
        /// <summary>
        /// Gets or sets the email address of the sender.
        /// </summary>
        public string Sender { get; set; }

        /// <summary>
        /// Gets or sets the name of the sender.
        /// </summary>
        public string SenderName { get; set; }

        /// <summary>
        /// Gets or sets the list of "To" recipient email addresses.
        /// </summary>
        public List<string> To { get; set; } = new List<string>();

        /// <summary>
        /// Gets or sets the list of "Cc" (Carbon Copy) recipient email addresses.
        /// </summary>
        public List<string> Cc { get; set; } = new List<string>();

        /// <summary>
        /// Gets or sets the list of "Bcc" (Blind Carbon Copy) recipient email addresses.
        /// </summary>
        public List<string> Bcc { get; set; } = new List<string>();

        /// <summary>
        /// Gets or sets the body content of the email.
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// Gets or sets the subject of the email.
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// Returns the email addresses of the "To" recipients as a semicolon-separated string.
        /// </summary>
        /// <returns>A string of "To" email addresses.</returns>
        public string GetToEmailString()
        {
            return BuildStringFromList(To);
        }

        /// <summary>
        /// Returns the email addresses of the "Cc" recipients as a semicolon-separated string.
        /// </summary>
        /// <returns>A string of "Cc" email addresses.</returns>
        public string GetCcEmailString()
        {
            return BuildStringFromList(Cc);
        }

        /// <summary>
        /// Returns the email addresses of the "Bcc" recipients as a semicolon-separated string.
        /// </summary>
        /// <returns>A string of "Bcc" email addresses.</returns>
        public string GetBccEmailString()
        {
            return BuildStringFromList(Bcc);
        }

        /// <summary>
        /// Builds a semicolon-separated string from a list of email addresses.
        /// </summary>
        /// <param name="emails">The list of email addresses to join.</param>
        /// <returns>A semicolon-separated string of email addresses.</returns>
        private string BuildStringFromList(List<string> emails)
        {
            return emails != null && emails.Count > 0 ? string.Join(";", emails.ToArray()) : string.Empty;
        }
    }
}
