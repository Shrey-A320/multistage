﻿namespace MWP.Notification.Domain.EmailModels
{
    /// <summary>
    /// Model representing an email notification request, containing metadata, email-specific data, and notification configurations.
    /// Implements the <see cref="INotificationRequestModel"/> interface.
    /// </summary>
    public class EmailRequestModel : INotificationRequestModel
    {
        /// <summary>
        /// Gets or sets the correlation ID for tracking the request.
        /// </summary>
        public Guid CorrelationId { get; set; }

        /// <summary>
        /// Gets or sets the context or description of the notification.
        /// </summary>
        public string Context { get; set; }

        /// <summary>
        /// Gets or sets the name or identifier of the user who created the request.
        /// </summary>
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets the timestamp when the notification was created.
        /// </summary>
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets the source of the notification (e.g., process).
        /// Defaults to <see cref="NotificationSource.Process"/>.
        public NotificationSource Source { get; set; } = NotificationSource.Process;

        /// <summary>
        /// Gets or sets the type of notification (e.g., email).
        /// Defaults to <see cref="NotificationType.Email"/>.
        public NotificationType NotificationType { get; set; } = NotificationType.Email;

        /// <summary>
        /// Gets or sets the severity level of the notification.
        /// Defaults to <see cref="NotificationSeverity.Information"/>.
        /// </summary>
        public NotificationSeverity Severity { get; set; } = NotificationSeverity.Information;

        /// <summary>
        /// Gets or sets whether the notification should be audited.
        /// </summary>
        public bool Audit { get; set; } = true;

        /// <summary>
        /// Gets or sets a list of email attachments for the notification.
        /// </summary>
        public List<string> Attachments { get; set; }

        /// <summary>
        /// Gets or sets the email provider to be used for sending the email.
        /// Defaults to <see cref="EmailProvider.SendGrid"/>.
        /// </summary>
        public EmailProvider EmailProvider { get; set; } = EmailProvider.SendGrid;

        /// <summary>
        /// Gets or sets the name of the container for storing email-related data.
        /// </summary>
        public string ContainerName { get; set; }

        /// <summary>
        /// Gets or sets the email header details, including sender and recipients.
        /// </summary>
        public EmailHeader EmailHeader { get; set; }

        /// <summary>
        /// Gets or sets a list of email addresses to notify in case of failure.
        /// </summary>
        public List<string> NotifyFailureEmail { get; set; }

        /// <summary>
        /// Gets or sets the folder name.
        /// </summary>
        public string FolderName { get; set; }
    }
}
