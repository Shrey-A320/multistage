﻿using MWP.Notification.Common.Constants;

namespace MWP.Notification.Domain.Validators
{
    public class EmailRequestModelValidator : AbstractValidator<EmailRequestModel>
    {
        public EmailRequestModelValidator()
        {
            RuleFor(x => x.CorrelationId).NotEmpty().WithMessage(ValidationMessages.CorrelationIdEmpty);
            RuleFor(x => x.Context).NotEmpty().WithMessage(ValidationMessages.ContextEmpty);
            RuleFor(x => x.CreatedBy).NotEmpty().WithMessage(ValidationMessages.CreatedByEmpty);
            RuleFor(x => x.CreatedOn).NotEmpty().WithMessage(ValidationMessages.CreatedOnEmpty);
            RuleFor(s => s.Source)
                .Must(x => Enum.IsDefined(typeof(NotificationSource), x))
                .WithMessage(ValidationMessages.SourceInvalid);
            RuleFor(s => s.NotificationType)
            .Must(x => Enum.IsDefined(typeof(NotificationType), x))
            .WithMessage(ValidationMessages.NotificationTypeInvalid);
            RuleFor(s => s.Severity)
            .Must(x => Enum.IsDefined(typeof(NotificationSeverity), x))
            .WithMessage(ValidationMessages.SeverityInvalid);
            RuleFor(s => s.EmailProvider)
            .Must(x => Enum.IsDefined(typeof(EmailProvider), x))
            .WithMessage(ValidationMessages.EmailProviderInvalid);
            RuleFor(x => x.EmailHeader).NotEmpty();
        }
    }
}
