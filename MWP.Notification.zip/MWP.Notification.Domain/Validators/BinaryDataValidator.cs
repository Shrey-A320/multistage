﻿namespace MWP.Notification.Domain.Validators
{
    public class BinaryDataValidator : AbstractValidator<BinaryData>
    {
        public BinaryDataValidator()
        {
            RuleFor(data => data)
                .NotNull().WithMessage("Binary data cannot be null.")
                .Must(data => !string.IsNullOrWhiteSpace(data.ToString())).WithMessage("Binary data cannot be empty or whitespace.");
        }
    }
}
