﻿using MWP.Notification.Common.Constants;

namespace MWP.Notification.Domain.Validators
{
    public class EmailHeaderValidator : AbstractValidator<EmailHeader>
    {
        public EmailHeaderValidator()
        {
            RuleFor(x => x.Sender).NotEmpty().WithMessage(ValidationMessages.SenderEmpty);
            RuleFor(x => x.SenderName).NotEmpty().WithMessage(ValidationMessages.SenderNameEmpty);
            RuleFor(x => x.To).NotEmpty().WithMessage(ValidationMessages.ToEmpty);
            RuleFor(x => x.To).Must(BeAValidEmail).WithMessage(ValidationMessages.ToInvalid);
            RuleFor(x => x.Cc).Must(BeAValidEmail).WithMessage(ValidationMessages.CcInvalid);
            RuleFor(x => x.Bcc).Must(BeAValidEmail).WithMessage(ValidationMessages.BccInvalid);
            RuleFor(x => x.Subject).NotEmpty().WithMessage(ValidationMessages.SubjectEmpty);

        }
        private bool BeAValidEmail(List<string> emailaddress)
        {
            // custom emailaddress validating logic goes here
            try
            {
                if (emailaddress == null || emailaddress.Count == 0) {
                    return true;
                }
                foreach (var email in emailaddress) {
                    MailAddress m = new MailAddress(email);
                }
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
