﻿global using MWP.Notification.Domain.Enums;
global using System.Text.Json.Serialization;
global using System.Text.Json;
global using FluentValidation;
global using MWP.Notification.Domain.EmailModels;
global using System.Net.Mail;
