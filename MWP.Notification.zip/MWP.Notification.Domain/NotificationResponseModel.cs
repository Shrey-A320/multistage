﻿namespace MWP.Notification.Domain
{
    /// <summary>
    /// Represents the response model for a notification request, containing status information, success flag, and error messages.
    /// </summary>
    public class NotificationResponseModel
    {
        /// <summary>
        /// Gets or sets the HTTP status code of the notification request response.
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// Gets or sets a flag indicating whether the notification request was successful.
        /// </summary>
        public bool IsSuccessStatusCode { get; set; }

        /// <summary>
        /// Gets or sets the error message if the notification request failed.
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="NotificationResponseModel"/> class with the specified status code, success flag, and error message.
        /// </summary>
        /// <param name="statusCode">The HTTP status code of the response.</param>
        /// <param name="isSuccessStatusCode">A flag indicating whether the request was successful.</param>
        /// <param name="errorMessage">An optional error message if the request failed.</param>
        public NotificationResponseModel(int statusCode, bool isSuccessStatusCode, string errorMessage)
        {
            StatusCode = statusCode;
            IsSuccessStatusCode = isSuccessStatusCode;
            ErrorMessage = errorMessage;
        }
    }
}
