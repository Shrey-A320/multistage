﻿namespace MWP.Notification.Common.Configurations
{
    [ExcludeFromCodeCoverage]
    public class NotificationConfiguration
    {
        public bool IsEncrypted { get; set; }
        public ValuesConfig Values { get; set; }
        public string FunctionName { get; set; }
        public string ApplicationId { get; set; }
        public string FromAddress { get; set; }
        public string SendGridApiKey { get; set; }
        public string BlobConnectionString { get; set; }
        public string BlobContainerName { get; set; }
        public string CosmosConnectionString { get; set; }
        public string CosmosDatabaseId { get; set; }
        public string CosmosContainerId { get; set; }
        public ApplicationInsightConfig ApplicationInsights { get; set; }
    }

    public class ValuesConfig
    {
        public string AzureWebJobsStorage { get; set; }
        public string FUNCTIONS_WORKER_RUNTIME { get; set; }
    }

    public class ApplicationInsightConfig
    {
        public string ConnectionString { get; set; }
        public string InstrumentationKey { get; set; }
    }
}
