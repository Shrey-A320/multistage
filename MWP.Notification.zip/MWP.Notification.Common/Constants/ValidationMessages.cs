﻿namespace MWP.Notification.Common.Constants
{
    public static class ValidationMessages
    {
        //EmailHeaderValidator
        public const string SenderEmpty ="Sender must not be empty or null.";
        public const string SenderNameEmpty="SenderName must not be empty or null.";
        public const string ToEmpty="To field must not be empty or null.";
        public const string ToInvalid ="Please specify valid To email address.";
        public const string CcInvalid ="Please specify valid Cc email address.";
        public const string BccInvalid ="Please specify valid Bcc email address.";
        public const string SubjectEmpty ="Subject must not be empty or null.";

        //EmailRequestModelValidator
        public const string CorrelationIdEmpty = "CorrelationId must not be empty or null";
        public const string ContextEmpty = "Context must not be empty or null";
        public const string CreatedByEmpty = "CreatedBy must not be empty or null";
        public const string CreatedOnEmpty = "CreatedOn must not be empty or null";
        public const string SourceInvalid = "Please provide a valid notification source type.";
        public const string NotificationTypeInvalid = "Please provide a valid notification type.";
        public const string SeverityInvalid = "Please provide a valid notification severity.";
        public const string EmailProviderInvalid = "Please provide a valid email provider.";   
                                                 
    }                                            
}                                                
                                                
                                                 

