﻿namespace MWP.Notification.Common.Constants
{
    public static class CommonConstants
    {
        public const string NotificationType = "NotificationType";
        public const string CorrelationIdHeaderName = "X-Correlation-Id";
    }
}
