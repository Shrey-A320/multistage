﻿namespace MWP.Notification.Infrastructure.Tests
{
    public class BlobStorageServiceTests
    {
        private readonly Mock<IAzureContextManager> _mockAzureContextManager;
        private readonly Mock<ILogger<BlobStorageService>> _mockLogger;
        private readonly Mock<BlobClient> _mockBlobClient;
        private readonly Mock<BlobContainerClient> _mockBlobContainerClient;
        private readonly BlobStorageService _blobStorageService;

        public BlobStorageServiceTests()
        {
            // Initialize the mocks
            _mockAzureContextManager = new Mock<IAzureContextManager>();
            _mockLogger = new Mock<ILogger<BlobStorageService>>();
            _mockBlobClient = new Mock<BlobClient>();
            _mockBlobContainerClient = new Mock<BlobContainerClient>();
            _blobStorageService = new BlobStorageService(_mockLogger.Object, _mockAzureContextManager.Object);
        }

        [Fact]
        public async Task GetAsync_ReturnsBlobMetaData_WhenBlobExists()
        {
            // Arrange
            var folderName = "test-folder";
            var blobName = "test-blob";
            var blobData = new byte[] { 1, 2, 3, 4, 5 };

            _mockBlobClient.Setup(b => b.DownloadToAsync(It.IsAny<Stream>()))
                          .Callback<Stream>(s => s.Write(blobData, 0, blobData.Length))
                          .Returns(Task.FromResult<Azure.Response>(Mock.Of<Azure.Response>()));

            _mockBlobContainerClient.Setup(c => c.GetBlobClient(It.IsAny<string>()))
                                   .Returns(_mockBlobClient.Object);

            _mockAzureContextManager.Setup(m => m.InitializeContainerClientAsync())
                                    .ReturnsAsync(_mockBlobContainerClient.Object);

            // Act
            var result = await _blobStorageService.GetAsync(folderName, blobName);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.IsSuccessful);
            Assert.Equal(blobData, result.DownloadedData);
        }

        [Fact]
        public async Task GetAsync_ThrowsInvalidOperationException_OnUnexpectedError()
        {
            // Arrange
            var folderName = "test-folder";
            var blobName = "test-blob";

            _mockBlobClient.Setup(b => b.DownloadToAsync(It.IsAny<Stream>()))
                          .ThrowsAsync(new Exception("Unexpected error"));

            _mockBlobContainerClient.Setup(c => c.GetBlobClient(It.IsAny<string>()))
                                   .Returns(_mockBlobClient.Object);

            _mockAzureContextManager.Setup(m => m.InitializeContainerClientAsync())
                                    .ReturnsAsync(_mockBlobContainerClient.Object);

            // Act & Assert
            var exception = await Assert.ThrowsAsync<InvalidOperationException>(() => _blobStorageService.GetAsync(folderName, blobName));
            Assert.Contains("An unexpected error occurred while downloading the blob", exception.Message);
        }

        [Fact]
        public async Task GetAsync_ThrowsFileNotFoundException_WhenBlobNotFound()
        {
            // Arrange
            var folderName = "test-folder";
            var blobName = "test-blob";

            // Mock the BlobClient to throw a FileNotFoundException when DownloadToAsync is called
            _mockBlobClient.Setup(b => b.DownloadToAsync(It.IsAny<Stream>()))
                          .ThrowsAsync(new FileNotFoundException());

            // Mock the BlobContainerClient to return the mocked BlobClient
            _mockBlobContainerClient.Setup(c => c.GetBlobClient(It.IsAny<string>()))
                                   .Returns(_mockBlobClient.Object);

            // Mock the AzureContextManager to return the mocked BlobContainerClient
            _mockAzureContextManager.Setup(m => m.InitializeContainerClientAsync())
                                    .ReturnsAsync(_mockBlobContainerClient.Object);

            // Act & Assert
            await Assert.ThrowsAsync<FileNotFoundException>(() => _blobStorageService.GetAsync(folderName, blobName));
        }
    }
} 
