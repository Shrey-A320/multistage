﻿using MWP.Notification.Infrastructure.Interfaces;

namespace MWP.Notification.Infrastructure.Tests
{
    public class AzureContextManagerTests
    {
        private readonly string _validConnectionString = "UseDevelopmentStorage=true";
        private readonly string _validContainerName = "test-container";
        private readonly Mock<BlobContainerClient> _mockBlobContainerClient;
        private readonly Mock<CosmosClient> _mockCosmosClient;
        private readonly Mock<Database> _mockDatabase;
        private readonly CosmosDbSettings _settings;
        private readonly AzureContextManager _azureContextManager;
        private readonly Mock<Azure.Response<BlobContainerInfo>> _blobContainerInfo;
        private readonly Mock<ILogger<AzureContextManager>> _logger;


        public AzureContextManagerTests()
        {
            _mockBlobContainerClient = new Mock<BlobContainerClient>(MockBehavior.Strict);
            _mockCosmosClient = new Mock<CosmosClient>(MockBehavior.Loose);
            _mockDatabase = new Mock<Database>(MockBehavior.Strict);
            _blobContainerInfo = new Mock<Azure.Response<BlobContainerInfo>>();
            _logger = new Mock<ILogger<AzureContextManager>>();

            _settings = new CosmosDbSettings("TestDatabaseId", "TestConnectionString", "TestContainerId", "/TestPartitionKey");

            _azureContextManager = new AzureContextManager(
                _mockCosmosClient.Object,
                _settings,
                "UseDevelopmentStorage=true",
                "test-container",
                _logger.Object
            );
        }

        [Fact]
        public void Constructor_ValidParameters_ShouldInitializeClients()
        {
            // Assert
            Assert.NotNull(_azureContextManager);
        }        

        [Fact]
        public async Task InitializeContainerClientAsync_ShouldInvokeCreateIfNotExistsOnce()
        {
            // Arrange
            var mockBlobContainerClient = new Mock<BlobContainerClient>(MockBehavior.Strict);
            mockBlobContainerClient
                .Setup(client => client.CreateIfNotExistsAsync(
                    It.IsAny<PublicAccessType>(),
                    It.IsAny<IDictionary<string, string>>(),
                    It.IsAny<BlobContainerEncryptionScopeOptions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Mock.Of<Azure.Response<BlobContainerInfo>>());

            var mockLogger = new Mock<ILogger<AzureContextManager>>();
            var azureContextManager = new AzureContextManager(
                _mockCosmosClient.Object,
                _settings,
                _validConnectionString,
                _validContainerName,
                mockLogger.Object);

            // Inject the mocked BlobContainerClient into the private field using reflection
            typeof(AzureContextManager)
                .GetField("_blobContainerClient", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(azureContextManager, mockBlobContainerClient.Object);

            // Act
            var result = await azureContextManager.InitializeContainerClientAsync();

            // Assert
            mockBlobContainerClient.Verify(client => client.CreateIfNotExistsAsync(
                It.IsAny<PublicAccessType>(),
                It.IsAny<IDictionary<string, string>>(),
                It.IsAny<BlobContainerEncryptionScopeOptions>(),
                It.IsAny<CancellationToken>()), Times.Once);

            Assert.NotNull(result); // Verify result is not null
        }

        [Fact]
        public async Task InitializeContainerClientAsync_ContainerAlreadyExists_ShouldNotThrow()
        {
            // Arrange
            var mockBlobContainerClient = new Mock<BlobContainerClient>(MockBehavior.Strict);
            mockBlobContainerClient
                .Setup(client => client.CreateIfNotExistsAsync(
                    It.IsAny<PublicAccessType>(),
                    It.IsAny<IDictionary<string, string>>(),
                    It.IsAny<BlobContainerEncryptionScopeOptions>(),
                    It.IsAny<CancellationToken>()))
                .ReturnsAsync(Mock.Of<Azure.Response<BlobContainerInfo>>());

            var mockLogger = new Mock<ILogger<AzureContextManager>>();
            var azureContextManager = new AzureContextManager(
                _mockCosmosClient.Object,
                _settings,
                _validConnectionString,
                _validContainerName,
                mockLogger.Object);

            // Inject the mocked BlobContainerClient into the private field using reflection
            typeof(AzureContextManager)
                .GetField("_blobContainerClient", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance)
                ?.SetValue(azureContextManager, mockBlobContainerClient.Object);

            // Act
            var result = await azureContextManager.InitializeContainerClientAsync();

            // Assert
            Assert.NotNull(result); // Verify that the result is not null
            mockBlobContainerClient.Verify(client => client.CreateIfNotExistsAsync(
                It.IsAny<PublicAccessType>(),
                It.IsAny<IDictionary<string, string>>(),
                It.IsAny<BlobContainerEncryptionScopeOptions>(),
                It.IsAny<CancellationToken>()), Times.Once); // Verify the method is called exactly once
        }


        [Fact]
        public void GetCosmosContainerClient_ShouldReturnContainer()
        {
            // Arrange
            var mockContainer = new Mock<Container>();
            _mockCosmosClient
                .Setup(client => client.GetContainer(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockContainer.Object);

            // Act
            var container = _azureContextManager.GetCosmosContainerClient("TestDatabaseId", "TestContainerId");

            // Assert
            Assert.NotNull(container);
            Assert.Equal(mockContainer.Object, container);
        }

        [Fact]
        public void GetCosmosContainerClient_ShouldThrowException_WhenContainerRetrievalFails()
        {
            // Arrange
            _mockCosmosClient
                .Setup(client => client.GetContainer(It.IsAny<string>(), It.IsAny<string>()))
                .Throws(new InvalidOperationException("Failed to get container"));

            // Act & Assert
            Assert.Throws<InvalidOperationException>(() => _azureContextManager.GetCosmosContainerClient("TestDatabaseId", "TestContainerId"));
        }

        [Fact]
        public async Task CreateDatabaseAsync_ShouldCallCreateDatabaseIfNotExistsAsync()
        {
            // Arrange
            _mockCosmosClient
            .Setup(client => client.CreateDatabaseIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbDatabaseID),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ))
            .ReturnsAsync(Mock.Of<DatabaseResponse>());

            // Act
            await _azureContextManager.CreateDatabaseAsync();

            // Assert
            _mockCosmosClient.Verify(client => client.CreateDatabaseIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbDatabaseID),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ), Times.Once);
        }

        [Fact]
        public async Task CreateDatabaseAsync_ShouldThrowException_WhenDatabaseCreationFails()
        {
            // Arrange
            _mockCosmosClient
            .Setup(client => client.CreateDatabaseIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbDatabaseID),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ))
            .ThrowsAsync(new Exception("Database creation failed"));

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => _azureContextManager.CreateDatabaseAsync());
        }

        [Fact]
        public async Task CreateContainerAsync_ShouldCallGetDatabaseAndCreateContainerIfNotExists()
        {
            // Arrange
            _mockDatabase
            .Setup(db => db.CreateContainerIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbContainerID),
                It.Is<string>(id => id == _settings.CosmosDbPartitionKey),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ))
            .ReturnsAsync(Mock.Of<ContainerResponse>());

            _mockCosmosClient
                .Setup(client => client.GetDatabase(It.IsAny<string>()))
                .Returns(_mockDatabase.Object);

            // Act
            await _azureContextManager.CreateContainerAsync();

            // Assert
            _mockCosmosClient.Verify(client => client.GetDatabase(_settings.CosmosDbDatabaseID), Times.Once);
            _mockDatabase.Verify(db => db.CreateContainerIfNotExistsAsync(
                _settings.CosmosDbContainerID,
                _settings.CosmosDbPartitionKey,
                null,
                null,
                It.IsAny<CancellationToken>()
            ), Times.Once);
        }

        [Fact]
        public async Task CreateContainerAsync_ShouldThrowException_WhenContainerCreationFails()
        {
            // Arrange
            _mockDatabase
            .Setup(db => db.CreateContainerIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbContainerID),
                It.Is<string>(id => id == _settings.CosmosDbPartitionKey),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ))
            .ThrowsAsync(new Exception("Container creation failed"));

            _mockCosmosClient
                .Setup(client => client.GetDatabase(It.IsAny<string>()))
                .Returns(_mockDatabase.Object);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => _azureContextManager.CreateContainerAsync());
        }

        [Fact]
        public async Task InitializeAsync_ShouldCreateDatabaseAndContainer()
        {
            // Arrange
            _mockDatabase
            .Setup(db => db.CreateContainerIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbContainerID),
                It.Is<string>(id => id == _settings.CosmosDbPartitionKey),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ))
            .ReturnsAsync(Mock.Of<ContainerResponse>());

            _mockCosmosClient
            .Setup(client => client.CreateDatabaseIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbDatabaseID),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ))
            .ReturnsAsync(Mock.Of<DatabaseResponse>());

            _mockCosmosClient.Setup(client => client.GetDatabase(It.IsAny<string>()))
                             .Returns(_mockDatabase.Object);

            // Act
            await _azureContextManager.InitializeAsync();

            // Assert
            _mockCosmosClient.Verify(client => client.CreateDatabaseIfNotExistsAsync(
                It.Is<string>(id => id == _settings.CosmosDbDatabaseID),
                It.Is<int?>(throughput => throughput == null),
                It.Is<RequestOptions>(options => options == null),
                It.IsAny<CancellationToken>()
            ), Times.Once);


            _mockCosmosClient.Verify(client => client.GetDatabase(_settings.CosmosDbDatabaseID), Times.Once);
            _mockDatabase.Verify(db => db.CreateContainerIfNotExistsAsync(
                _settings.CosmosDbContainerID,
                _settings.CosmosDbPartitionKey,
                null,
                null,
                It.IsAny<CancellationToken>()
            ), Times.Once);
        }
    }
}