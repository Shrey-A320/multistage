﻿namespace MWP.Notification.Infrastructure.Tests
{
    public class EmailSenderTests
    {
        private readonly EmailSender _emailSender;
        private readonly Mock<ISendGridClient> _mockSendGridClient;
        private readonly Mock<ILogger<EmailSender>> _mockLogger;
        private readonly Mock<IBlobStorageService> _mockBlobStorageService;

        public EmailSenderTests()
        {
            _mockSendGridClient = new Mock<ISendGridClient>();
            _mockLogger = new Mock<ILogger<EmailSender>>();
            _mockBlobStorageService = new Mock<IBlobStorageService>();
            _emailSender = new EmailSender(_mockBlobStorageService.Object, _mockLogger.Object, _mockSendGridClient.Object);
        }

        [Fact]
        public async Task SendEmailAsync_BasicReturnsAccepted_OnSuccessfulSend()
        {
            SendGrid.Response response = new SendGrid.Response(System.Net.HttpStatusCode.Accepted, null, null);

            _mockSendGridClient.Setup(i => i.SendEmailAsync(It.IsAny<SendGridMessage>(), It.IsAny<CancellationToken>()))
                .Returns(Task.FromResult(response));

            var actualResponse = await _emailSender.SendEmailAsync("FromAddress", "ToAddress", "Test Subject", "Test Body", new List<string>(), It.IsAny<string>()).ConfigureAwait(true);

            Assert.True(actualResponse.IsSuccessStatusCode);
        }

        [Fact]
        public async Task SendEmailAsync_WithAttachments_ShouldSendEmailWithAttachments()
        {
            // Arrange
            SendGrid.Response response = new SendGrid.Response(HttpStatusCode.Accepted, null, null);
            _mockSendGridClient.Setup(c => c.SendEmailAsync(It.IsAny<SendGridMessage>(), default)).ReturnsAsync(response);
            _mockBlobStorageService.Setup(s => s.GetAsync(It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(new Models.BlobMetaData { DownloadedData = new byte[] { 1, 2, 3 } });

            // Act
            var result = await _emailSender.SendEmailAsync("from@example.com", "to@example.com", "subject", "body", new List<string> { "attachmentKey" }, It.IsAny<string>());

            // Assert
            Assert.True(result.IsSuccessStatusCode);
            _mockSendGridClient.Verify(c => c.SendEmailAsync(It.IsAny<SendGridMessage>(), default), Times.Once);
            _mockBlobStorageService.Verify(s => s.GetAsync(It.IsAny<string>(), It.IsAny<string>()), Times.Once);
        }

        [Fact]
        public async Task SendEmailAsync_WithCCAndBCC_ShouldSendEmailWithCCAndBCC()
        {
            // Arrange
            var response = new SendGrid.Response(HttpStatusCode.Accepted, null, null);
            _mockSendGridClient.Setup(c => c.SendEmailAsync(It.IsAny<SendGridMessage>(), default)).ReturnsAsync(response);

            // Act
            var result = await _emailSender.SendEmailAsync("from@example.com", "to@example.com", "cc@example.com", "bcc@example.com", "subject", "body", new List<string>(), It.IsAny<string>());

            // Assert
            Assert.True(result.IsSuccessStatusCode);
            _mockSendGridClient.Verify(c => c.SendEmailAsync(It.IsAny<SendGridMessage>(), default), Times.Once);
        }

        [Fact]
        public async Task SendEmailAsync_NoRecipients_ShouldThrowException()
        {
            // Act & Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => _emailSender.SendEmailAsync("from@example.com", "", "", "", "subject", "body", new List<string>(), It.IsAny<string>()));
        }

        [Fact]
        public async Task SendEmailAsync_SendGridFailure_ShouldLogError()
        {
            // Arrange
            var response = new SendGrid.Response(HttpStatusCode.BadRequest, null, null);
            _mockSendGridClient.Setup(c => c.SendEmailAsync(It.IsAny<SendGridMessage>(), default)).ReturnsAsync(response);

            // Act & Assert
            await Assert.ThrowsAsync<HttpRequestException>(() => _emailSender.SendEmailAsync("from@example.com", "to@example.com", "subject", "body", new List<string>(), It.IsAny<string>()));
            _mockLogger.Verify(
                    x => x.Log(
                    It.Is<LogLevel>(l => l == LogLevel.Error),
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => true),
                    It.IsAny<Exception>(),
                    It.Is<Func<It.IsAnyType, Exception, string>>((v, t) => true)), Times.AtLeast(2));
        }
    }
}
