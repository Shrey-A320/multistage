global using Xunit;
global using Azure.Storage.Blobs;
global using Microsoft.Extensions.Logging;
global using Moq;
global using MWP.Notification.Infrastructure.Interfaces;
global using Azure;
global using Azure.Storage.Blobs.Models;
global using SendGrid.Helpers.Mail;
global using SendGrid;
global using System.Net;
global using Microsoft.Azure.Cosmos;
global using MWP.Notification.Infrastructure.Models;
global using MWP.TradeService.TestUtilities.Builders.Dtos;
global using MWP.Notification.Infrastructure.Repositories;


