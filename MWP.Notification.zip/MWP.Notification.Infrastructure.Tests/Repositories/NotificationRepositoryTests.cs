namespace MWP.Notification.Infrastructure.Tests.Repositories
{
    public class NotificationRepositoryTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}