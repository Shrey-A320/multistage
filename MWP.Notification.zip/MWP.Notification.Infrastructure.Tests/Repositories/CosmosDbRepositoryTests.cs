﻿namespace MWP.Notification.Infrastructure.Tests.Repositories
{
    public class CosmosDbRepositoryTests
    {
        private readonly CosmosDbSettings _settings;
        private readonly CosmosDbRepository _cosmosDbRepository;
        private readonly Mock<IAzureContextManager> _mockAzureContextManager;
        private readonly Mock<ILogger<CosmosDbRepository>> _mockLogger;


        public CosmosDbRepositoryTests()
        {
            _mockAzureContextManager = new Mock<IAzureContextManager>();
            _mockLogger = new Mock<ILogger<CosmosDbRepository>>();
            _settings = new CosmosDbSettings("TestDatabaseId", "TestConnectionString", "TestContainerId", "/TestPartitionKey");

            _cosmosDbRepository = new CosmosDbRepository(
                _mockAzureContextManager.Object,
                _settings,
                _mockLogger.Object
            );
        }

        [Fact]
        public async Task AddRecords_ShouldReturnTrue_WhenRecordIsAddedSuccessfully()
        {
            // Arrange
            var mockContainer = new Mock<Container>();
            _mockAzureContextManager
                .Setup(client => client.GetCosmosContainerClient(It.IsAny<string>(), It.IsAny<string>()))
                .Returns(mockContainer.Object);

            var testRecord = new { Id = 1, Name = "Test" };
            var mockItemResponse = new Mock<ItemResponse<object>>();
            mockItemResponse.SetupGet(x => x.Resource).Returns(testRecord);

            mockContainer
            .Setup(db => db.CreateItemAsync(It.IsAny<object>(), It.IsAny<PartitionKey>(), It.IsAny<ItemRequestOptions>(), It.IsAny<CancellationToken>()
            )).ReturnsAsync(mockItemResponse.Object);

            // Act & Assert
            var result = await _cosmosDbRepository.AddRecords(testRecord);
            Assert.True(result);

            _mockAzureContextManager.Verify(client => client.GetCosmosContainerClient(It.IsAny<string>(), It.IsAny<string>()
            ), Times.Once);

        }

        [Fact]
        public async Task AddRecords_ShouldReturnFalse_WhenConatinerCreationFailed()
        {
            // Arrange
            var mockContainer = new Mock<Container>();
            _mockAzureContextManager
                .Setup(client => client.GetCosmosContainerClient(It.IsAny<string>(), It.IsAny<string>())).
                Throws(new Exception("Container creation failed"));

            var testRecord = new { Id = 1, Name = "Test" };
            var mockItemResponse = new Mock<ItemResponse<object>>();
            mockItemResponse.SetupGet(x => x.Resource).Returns(testRecord);

            mockContainer
            .Setup(db => db.CreateItemAsync(It.IsAny<object>(), It.IsAny<PartitionKey>(), It.IsAny<ItemRequestOptions>(), It.IsAny<CancellationToken>()
            )).ReturnsAsync(mockItemResponse.Object);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() => _cosmosDbRepository.AddRecords(testRecord));
            
        }

    }
}
