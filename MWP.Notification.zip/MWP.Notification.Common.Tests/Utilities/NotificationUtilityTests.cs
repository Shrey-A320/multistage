namespace MWP.Notification.Common.Tests.Utilities
{
    public class NotificationUtilityTests
    {
        [Fact]
        public void Test1()
        {

        }
    }
}